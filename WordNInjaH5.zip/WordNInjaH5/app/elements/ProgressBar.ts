module RoyalFlush {

    export class ProgressBar extends PIXI.Container {

        constructor() {
            super();
        }


    }
} 